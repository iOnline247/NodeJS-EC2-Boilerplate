"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const uuid_1 = require("uuid");
const logger_1 = __importDefault(require("./logger"));
const logger = new logger_1.default({
    appName: "nodejs-ec2-boilerplate",
    component: "Typescript",
    module: "DX",
    correlationId: uuid_1.v4(),
    jobId: uuid_1.v4(),
});
logger.on(logger_1.default.EVENTS.LOGGING, async (payload) => {
    console.log(`Logger event fired: ${logger_1.default.EVENTS.LOGGING}`);
    console.log(payload);
});
logger.on(logger_1.default.EVENTS.LOGGED, async (payload) => {
    console.log(`Logger event fired: ${logger_1.default.EVENTS.LOGGED}`);
    console.log(payload);
});
logger.log("Hola, Mundo");
logger.error("NOPE");
//# sourceMappingURL=index.js.map